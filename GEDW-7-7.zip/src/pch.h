#pragma once
#include <vector>
#include <unordered_map>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <numeric>
#include <regex>

#include "math/All.h"
#include "gfx/All.h"
#include "Core.h"

